package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.painterResource
import com.example.R
import com.example.model.OutputType
import com.example.ui.MainViewModel
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentGreenBright
import com.example.ui.theme.AccentViolet
import com.example.ui.theme.DarkInputBg
import com.example.ui.theme.DarkInputBorder
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavyCardBorder
import com.example.ui.theme.DarkObsidianBg
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onStartBuild: () -> Unit,
    onNavigateToTab: (ScreenTab) -> Unit = {}
) {
    val projectMetadata by viewModel.projectMetadata.collectAsState()
    val selectedOutputType by viewModel.selectedOutputType.collectAsState()

    val sourceTab by viewModel.sourceTab.collectAsState()
    val configSubTab by viewModel.configSubTab.collectAsState()

    val appNameInput by viewModel.appNameInput.collectAsState()
    val packageNameInput by viewModel.packageNameInput.collectAsState()
    val versionNameInput by viewModel.versionNameInput.collectAsState()
    val versionCodeInput by viewModel.versionCodeInput.collectAsState()
    val targetSdkInput by viewModel.targetSdkInput.collectAsState()
    val hardwareAccelEnabled by viewModel.hardwareAccelEnabled.collectAsState()

    var showSdkDropdown by remember { mutableStateOf(false) }

    val sdkOptions = listOf(
        "API Level 35 (Android 15 - รุ่นล่าสุด)",
        "API Level 34 (Android 14)",
        "API Level 33 (Android 13)",
        "API Level 31 (Android 12)",
        "API Level 24 (Android 7.0 - Minimum)"
    )

    val zipPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            val fileName = uri.path?.substringAfterLast('/') ?: "project.zip"
            viewModel.processSelectedZipUri(uri, fileName)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkObsidianBg)
            .padding(6.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Environment Status Pills Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF111827))
                    .border(1.dp, Color(0xFF1F2937), RoundedCornerShape(12.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(5.dp).clip(CircleShape).background(AccentGreen))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Android 15 Native Environment", fontSize = 9.5.sp, color = TextWhite, fontWeight = FontWeight.SemiBold)
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF111827))
                    .border(1.dp, Color(0xFF1F2937), RoundedCornerShape(12.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = AccentGreen, modifier = Modifier.size(10.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("ระบบปฏิบัติการจริง (Production Mode)", fontSize = 9.5.sp, color = TextWhite)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // -------------------------------------------------------------
        // HERO BANNER CARD
        // -------------------------------------------------------------
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkNavyCardBorder)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                // Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(AccentGreen.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(4.dp).clip(CircleShape).background(AccentGreen))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ระบบปฏิบัติการจริง · Production Engine Kotlin 2.1 & SDK 35", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = AccentGreen)
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "APK Builder Pro (Production Engine)",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "ระบบปฏิบัติการจริงสำหรับแปลงไฟล์ ZIP โปรเจกต์เป็น APK/XAPK พร้อมลงชื่อ SHA-256 และส่งออกไปใช้งานจริงบน Android Device ได้ 100%",
                    fontSize = 10.5.sp,
                    color = TextMuted,
                    lineHeight = 14.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(
                        onClick = { onNavigateToTab(ScreenTab.KOTLIN_SDK) },
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentGreen)
                    ) {
                        Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("ดูโค้ด Native Kotlin", fontSize = 9.5.sp)
                    }

                    OutlinedButton(
                        onClick = { onNavigateToTab(ScreenTab.GALLERY) },
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentAmber)
                    ) {
                        Text("App Gallery", fontSize = 9.5.sp)
                        Spacer(modifier = Modifier.width(3.dp))
                        Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(12.dp))
                    }

                    OutlinedButton(
                        onClick = {},
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextWhite)
                    ) {
                        Text("GitHub", fontSize = 9.5.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // -------------------------------------------------------------
        // STEP 1 CARD: นำเข้าไฟล์ซอร์สโค้ด
        // -------------------------------------------------------------
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkNavyCardBorder)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                // Header
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(AccentGreen))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ขั้นตอนที่ 1 : นำเข้าไฟล์ซอร์สโค้ด", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = AccentGreen)
                }

                Text("เลือกไฟล์ ZIP โปรเจกต์", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)

                Spacer(modifier = Modifier.height(6.dp))

                // Source Tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkInputBg)
                        .padding(2.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    listOf("อุปกรณ์", "คลาวด์ (Drive/Dropbox)", "โปรเจกต์อ้างอิง").forEachIndexed { index, title ->
                        val isSelected = sourceTab == index
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) Color(0xFF1E293B) else Color.Transparent)
                                .clickable {
                                    viewModel.sourceTab.value = index
                                    if (index == 1) viewModel.openCloudImport()
                                    if (index == 2) viewModel.loadSampleProject(viewModel.sampleProjects.first())
                                }
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = title,
                                fontSize = 9.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) TextWhite else TextMuted,
                                textAlign = TextAlign.Center,
                                lineHeight = 12.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Drag & Drop Box (Dashed Area)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF0D1322))
                        .border(1.dp, DarkInputBorder, RoundedCornerShape(10.dp))
                        .clickable { zipPickerLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed")) }
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF1A2338)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CloudDownload, contentDescription = "Upload", tint = AccentBlue, modifier = Modifier.size(20.dp))
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        val annotatedText = buildAnnotatedString {
                            append("ลากไฟล์ ZIP มาวางที่นี่ หรือ ")
                            withStyle(style = SpanStyle(color = AccentBlue, textDecoration = TextDecoration.Underline, fontWeight = FontWeight.Bold)) {
                                append("คลิกเลือกจากอุปกรณ์")
                            }
                        }
                        Text(text = annotatedText, fontSize = 11.sp, color = TextWhite)

                        Spacer(modifier = Modifier.height(3.dp))

                        Text(
                            text = "รองรับ React Native, Flutter, Xamarin, .NET MAUI, Ionic, Capacitor, Native Android (Gradle) และ AI Studio",
                            fontSize = 9.5.sp,
                            color = TextDim,
                            textAlign = TextAlign.Center,
                            lineHeight = 13.sp,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // Framework Badges
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                FrameworkChip("🦋 Flutter & ⚛️ React Native")
                                FrameworkChip("🟣 .NET MAUI & 📱 Xamarin")
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                FrameworkChip("⚡ Ionic / Capacitor / 📦 Cordova")
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                FrameworkChip("🤖 Native Android Gradle", isActive = true)
                                FrameworkChip("✨ Google AI Studio")
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // -------------------------------------------------------------
        // STEP 2 CARD: กำหนดค่าการคอมไพล์และแพ็กเกจ
        // -------------------------------------------------------------
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkNavyCardBorder)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                // Header
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(AccentGreen))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ขั้นตอนที่ 2 : กำหนดค่าการคอมไพล์และแพ็กเกจ", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = AccentGreen)
                }

                Text("การตั้งค่า APK & สถาปัตยกรรม Android", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)

                Spacer(modifier = Modifier.height(6.dp))

                // Config Sub-Tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkInputBg)
                        .padding(2.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    listOf("ทั่วไป & รูปแบบ", "การลงชื่อ (Keystore)", "สิทธิ์ของแอพ (5)", "แก้ไข build.gradle").forEachIndexed { index, title ->
                        val isSelected = configSubTab == index
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) Color(0xFF1E293B) else Color.Transparent)
                                .clickable {
                                    viewModel.configSubTab.value = index
                                    if (index == 3) viewModel.openCodeEditor()
                                }
                                .padding(vertical = 5.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = title,
                                fontSize = 9.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) TextWhite else TextMuted,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Output Format Radio Cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ตัวเลือก OUTPUT : รูปแบบไฟล์ผลลัพธ์", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Text("พร้อมติดตั้งและส่งขึ้นสโตร์", fontSize = 9.5.sp, color = TextMuted)
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Option 1: APK Standalone
                OutputRadioCard(
                    title = "APK Standalone",
                    badge = "ยอดนิยม",
                    badgeColor = AccentGreen,
                    subtitle = "ไฟล์ติดตั้งลงบนมือถือ Android ได้ทันที",
                    icon = Icons.Default.PhoneAndroid,
                    isSelected = selectedOutputType == OutputType.APK,
                    onSelect = { viewModel.selectOutputType(OutputType.APK) }
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Option 2: XAPK Bundle
                OutputRadioCard(
                    title = "XAPK (Bundle)",
                    badge = null,
                    badgeColor = AccentBlue,
                    subtitle = "รวม Split APKs, OBB & Manifest สำหรับสโตร์",
                    icon = Icons.Default.Layers,
                    isSelected = selectedOutputType == OutputType.XAPK,
                    onSelect = { viewModel.selectOutputType(OutputType.XAPK) }
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Option 3: AAB
                OutputRadioCard(
                    title = "AAB (Play Store)",
                    badge = "Play Store",
                    badgeColor = AccentBlue,
                    subtitle = "Android App Bundle สำหรับอัปโหลดขึ้น Play Console",
                    icon = Icons.Default.Layers,
                    isSelected = false,
                    onSelect = { viewModel.selectOutputType(OutputType.XAPK) }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // App Icon Settings Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkInputBg)
                        .border(1.dp, DarkInputBorder, RoundedCornerShape(10.dp))
                        .padding(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1E293B)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (projectMetadata?.appIconBitmap != null) {
                                Image(
                                    bitmap = projectMetadata!!.appIconBitmap!!.asImageBitmap(),
                                    contentDescription = "Icon",
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Image(
                                    painter = painterResource(id = R.drawable.ic_app_logo),
                                    contentDescription = "App Logo",
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("ไอคอนแอพพลิเคชัน (APP ICON)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                                Spacer(modifier = Modifier.width(4.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(AccentBlue.copy(alpha = 0.2f))
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text("ใช้โลโก้เดียวกับ Header", fontSize = 8.5.sp, color = AccentBlue)
                                }
                            }
                            Text("ใช้รูปเดียวกับโลโก้บน Header (Adaptive Icon)", fontSize = 9.5.sp, color = TextDim)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                OutlinedButton(onClick = {}, shape = RoundedCornerShape(4.dp)) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(10.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text("ใช้โลโก้ Header", fontSize = 9.sp)
                                }
                                OutlinedButton(onClick = {}, shape = RoundedCornerShape(4.dp)) {
                                    Text("เลือกรูปใหม่", fontSize = 9.sp)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Input 1: App Name
                InputFieldWithNote(
                    label = "ชื่อแอพพลิเคชัน (App Name)",
                    note = "ชื่อไอคอนบนหน้าจอ",
                    value = appNameInput,
                    onValueChange = { viewModel.appNameInput.value = it }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Input 2: Package Name
                InputFieldWithNote(
                    label = "แพ็กเกจ (Package Name / ApplicationId)",
                    note = "ห้ามซ้ำบนสโตร์",
                    value = packageNameInput,
                    onValueChange = { viewModel.packageNameInput.value = it }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Input 3: Version Name
                InputFieldWithNote(
                    label = "เวอร์ชัน (Version Name)",
                    note = "เช่น 1.0.0",
                    value = versionNameInput,
                    onValueChange = { viewModel.versionNameInput.value = it }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Input 4: Version Code
                InputFieldWithNote(
                    label = "รหัสเวอร์ชัน (Version Code)",
                    note = "ตัวเลขจำนวนเต็ม",
                    value = versionCodeInput,
                    onValueChange = { viewModel.versionCodeInput.value = it }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Input 5: Target SDK Dropdown
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Target SDK (เป้าหมายระบบ Android)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                        Text("Android 15 (ล่าสุด)", fontSize = 9.5.sp, color = AccentGreen)
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    Box {
                        OutlinedTextField(
                            value = targetSdkInput,
                            onValueChange = {},
                            readOnly = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showSdkDropdown = true },
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = DarkInputBg,
                                unfocusedContainerColor = DarkInputBg,
                                focusedBorderColor = AccentBlue,
                                unfocusedBorderColor = DarkInputBorder,
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite
                            )
                        )

                        DropdownMenu(
                            expanded = showSdkDropdown,
                            onDismissRequest = { showSdkDropdown = false }
                        ) {
                            sdkOptions.forEach { option ->
                                DropdownMenuItem(
                                    text = { Text(option, fontSize = 11.sp) },
                                    onClick = {
                                        viewModel.targetSdkInput.value = option
                                        showSdkDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Hardware Acceleration Toggle Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkInputBg)
                        .border(1.dp, DarkInputBorder, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("⚙️ เปิดใช้ Hardware Acceleration", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Text("เร่งความเร็วการเรนเดอร์ GPU บนมือถือ", fontSize = 9.5.sp, color = TextDim)
                        }
                        Checkbox(
                            checked = hardwareAccelEnabled,
                            onCheckedChange = { viewModel.hardwareAccelEnabled.value = it },
                            colors = CheckboxDefaults.colors(checkedColor = AccentBlue)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Preview & Edit build.gradle Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(10.dp))
                        .padding(8.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Description, contentDescription = null, tint = AccentBlue, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("พรีวิวและปรับแต่ง build.gradle", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(AccentGreen.copy(alpha = 0.2f))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text("พร้อมใช้งาน", fontSize = 8.5.sp, color = AccentGreen)
                            }
                        }

                        Spacer(modifier = Modifier.height(3.dp))

                        Text("ปรับเปลี่ยน dependencies หรือ SDK versions ด้วยตนเอง หากระบบตรวจจับโครงสร้างไม่สมบูรณ์", fontSize = 9.5.sp, color = TextDim)

                        Spacer(modifier = Modifier.height(6.dp))

                        OutlinedButton(
                            onClick = { viewModel.openCodeEditor() },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentBlue)
                        ) {
                            Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("เปิดตัวแก้ไข build.gradle", fontSize = 10.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // CONVERT ACTION BUTTON
                Button(
                    onClick = {
                        viewModel.startBuildProcess()
                        onStartBuild()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("start_apk_build_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AccentBlue.copy(alpha = 0.5f))
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = AccentBlue, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "เริ่มแปลงเป็น APK และลงชื่ออัตโนมัติ",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "ⓘ กรุณาเลือกไฟล์ ZIP โปรเจกต์ในขั้นตอนที่ 1 ก่อนเริ่มสร้าง APK",
                    fontSize = 10.sp,
                    color = AccentAmber,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // FOOTER TEXT
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "APK Builder Pro (Native Android Edition) • สถาปัตยกรรม Kotlin 2.1 & Android SDK 35",
                fontSize = 9.5.sp,
                color = TextDim,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Native Android Architecture • รองรับการดาวน์โหลดและเปิดใน Android Studio 100%",
                fontSize = 9.5.sp,
                color = TextDim,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun FrameworkChip(title: String, isActive: Boolean = false) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isActive) AccentGreen.copy(alpha = 0.2f) else Color(0xFF1A2338))
            .border(1.dp, if (isActive) AccentGreen else Color(0xFF243048), RoundedCornerShape(10.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(title, fontSize = 9.5.sp, color = if (isActive) AccentGreenBright else TextMuted)
    }
}

@Composable
fun OutputRadioCard(
    title: String,
    badge: String?,
    badgeColor: Color,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(DarkInputBg)
            .border(1.dp, if (isSelected) AccentBlue else DarkInputBorder, RoundedCornerShape(10.dp))
            .clickable { onSelect() }
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF1E293B)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = AccentBlue, modifier = Modifier.size(16.dp))
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(title, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    if (badge != null) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(badgeColor.copy(alpha = 0.2f))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(badge, fontSize = 8.5.sp, color = badgeColor, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Text(subtitle, fontSize = 9.5.sp, color = TextDim)
            }

            RadioButton(
                selected = isSelected,
                onClick = onSelect,
                colors = RadioButtonDefaults.colors(selectedColor = AccentBlue)
            )
        }
    }
}

@Composable
fun InputFieldWithNote(
    label: String,
    note: String,
    value: String,
    onValueChange: (String) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
            Text(note, fontSize = 9.5.sp, color = TextMuted)
        }

        Spacer(modifier = Modifier.height(2.dp))

        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = DarkInputBg,
                unfocusedContainerColor = DarkInputBg,
                focusedBorderColor = AccentBlue,
                unfocusedBorderColor = DarkInputBorder,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite
            ),
            singleLine = true
        )
    }
}
