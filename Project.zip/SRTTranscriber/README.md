# SRT Transcriber — build บนมือถือด้วย AndroidIDE (ไม่ต้องใช้ PC)

## เตรียมครั้งเดียว
1. ติดตั้ง AndroidIDE (github.com/AndroidIDEOfficial/AndroidIDE → Releases, ไฟล์ arm64-v8a)
2. ใน AndroidIDE ติดตั้ง SDK Tools ให้ครบ: Platform 34, Build-Tools, NDK, CMake, JDK 17
3. แตกไฟล์ zip ไว้ในพื้นที่ที่ AndroidIDE เข้าถึงได้ (เช่น Download/SRTTranscriber)

## Build
1. AndroidIDE → Open project → เลือกโฟลเดอร์ SRTTranscriber → รอ Gradle sync
   (ต้องมี WiFi ครั้งแรก: CMake จะโหลด whisper.cpp v1.7.6 ให้เอง)
2. Build → Run task → `assembleDebug`
3. APK อยู่ที่ `app/build/outputs/apk/debug/app-debug.apk` → แตะติดตั้ง

## ถ้า CMake/NDK ไม่ถูกพบ
สร้าง `local.properties` ในโฟลเดอร์โปรเจกต์:
sdk.dir=/path/to/android-sdk
cmake.dir=/path/to/android-sdk/cmake/<เวอร์ชัน>
ndk.dir=/path/to/android-sdk/ndk/<เวอร์ชัน>

ถ้าโหลด whisper.cpp ไม่ได้: ดาวน์โหลด zip v1.7.6 แล้วแตกเป็น `app/src/main/cpp/whisper.cpp/`

## ใช้งาน
เลือก "Kotoba Whisper 2.0 (q5_0)" → "เลือกไฟล์จากเครื่อง" → ไฟล์ `ggml-kotoba-whisper-v2.0-q5_0.bin`
(คัดลอกเข้าแอปครั้งเดียว) → เลือกไฟล์เสียง → เริ่มถอดเสียง

HyperOS: การตั้งค่า → แอป → SRT Transcriber → ประหยัดแบตเตอรี่ = ไม่จำกัด
