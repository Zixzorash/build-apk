// สะพานเชื่อม UI ↔ Java (WebView). ทำงานเฉพาะในแอป Android
(() => {
  if (!window.Android) return;
  $('demo').hidden = true;
  const pend = {}, ls = {}; let n = 0;
  window.__res = (id, ok, v) => { const p = pend[id]; delete pend[id]; ok ? p.r(v) : p.j(new Error(v && v.error || 'error')); };
  window.__ev = (e, v) => (ls[e] || []).forEach(f => f(v));
  const call = (m, a = {}) => new Promise((r, j) => { const id = 'c' + (++n); pend[id] = { r, j }; Android.call(id, m, JSON.stringify(a)); });
  const on = (e, f) => { (ls[e] = ls[e] || []).push(f); return () => { ls[e] = ls[e].filter(x => x !== f); }; };
  const nm = () => MODELS[$('model').value].n;

  refreshModel = async function () {
    const k = $('model').value, ok = (await call('hasModel', { name: MODELS[k].n })).exists;
    $('mstat').textContent = ok ? '✓ พร้อมใช้งาน (' + MODELS[k].n + ')' : 'ยังไม่มีโมเดล — ดาวน์โหลด (ครั้งเดียว) หรือเลือกไฟล์ .bin จากเครื่อง';
    $('dl').disabled = !MODELS[k].u; $('dl').textContent = MODELS[k].u ? 'ดาวน์โหลดโมเดล' : 'ไม่มีลิงก์ (เลือกไฟล์เอง)';
  };
  $('model').onchange = refreshModel; refreshModel();

  const withProg = async (fn, label) => {
    $('dbar').hidden = false; $('dfill').style.width = '0'; $('mstat').textContent = label;
    const off = on('dlprogress', e => { $('dfill').style.width = e.p + '%'; });
    try { await fn(); } catch (e) { if (e.message !== 'cancelled') { $('dbar').hidden = true; off(); $('mstat').textContent = 'ผิดพลาด: ' + e.message; return; } }
    off(); $('dbar').hidden = true; refreshModel();
  };
  $('dl').onclick = () => withProg(() => call('downloadModel', { url: MODELS[$('model').value].u, name: nm() }), 'กำลังดาวน์โหลด…');
  $('pick').onclick = () => withProg(() => call('pickModel', { name: nm() }), 'กำลังคัดลอกโมเดลเข้าแอป…');

  $('file').addEventListener('click', async e => {
    e.preventDefault();
    try { const r = await call('pickAudio'); media = { uri: r.uri, name: r.name }; dur = r.durationMs;
      $('et').value = fmt(dur); $('finfo').textContent = r.name + ' • ความยาว ' + fmt(dur); } catch (_) {}
  }, true);

  $('go').onclick = async () => {
    if (!media) { alert('กรุณาเลือกไฟล์เสียงก่อน'); return; }
    if (!(await call('hasModel', { name: nm() })).exists) { alert('ยังไม่มีโมเดล'); return; }
    segs = []; $('out').textContent = ''; $('go').disabled = true; prog(0); step(0);
    const offs = [on('segment', s => { segs.push(s); render(); }), on('progress', e => prog(e.p)), on('step', e => step(e.n))];
    try {
      await call('transcribe', { uri: media.uri, model: nm(), lang: $('alang').value, translate: !!$('olang').value,
        vad: $('mode').value === 'vad', startMs: parse($('st').value), endMs: parse($('et').value) || dur, chunkSec: +$('chunk').value * 60 });
    } catch (e) { $('out').textContent += '\nผิดพลาด: ' + e.message; }
    offs.forEach(f => f()); render(); prog(1); step(5); $('go').disabled = false;
  };
  $('cp').onclick = () => { Android.copy($('out').textContent); $('cp').textContent = 'คัดลอกแล้ว ✓'; setTimeout(() => $('cp').textContent = 'คัดลอก', 1200); };
  $('sv').onclick = () => call('saveFile', { name: (media ? media.name.replace(/\.[^.]+$/, '') : 'subtitle') + '.' + $('fmt').value, text: $('out').textContent }).catch(() => {});
})();
