package com.srt.transcriber;
import android.content.Context;
import android.media.*;
import android.net.Uri;
import java.io.*;
import java.nio.*;

class AudioDecoder {
  static long durationMs(Context c, Uri u) {
    MediaMetadataRetriever r = new MediaMetadataRetriever();
    try { r.setDataSource(c, u); return Long.parseLong(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)); }
    catch (Exception e) { return 0; } finally { try { r.release(); } catch (Exception ig) {} }
  }

  /** ถอด [startMs,endMs] เป็น mono 16kHz PCM16 LE ลงไฟล์ (ใช้ดิสก์ ไม่กิน RAM) คืนจำนวน sample */
  static long decode(Context ctx, Uri uri, long startMs, long endMs, File out) throws Exception {
    MediaExtractor ex = new MediaExtractor(); ex.setDataSource(ctx, uri, null);
    int tr = -1; MediaFormat f = null;
    for (int i = 0; i < ex.getTrackCount(); i++) { MediaFormat t = ex.getTrackFormat(i);
      if (t.getString(MediaFormat.KEY_MIME).startsWith("audio/")) { tr = i; f = t; break; } }
    if (tr < 0) throw new IOException("ไม่พบ audio track");
    ex.selectTrack(tr); ex.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
    MediaCodec dec = MediaCodec.createDecoderByType(f.getString(MediaFormat.KEY_MIME));
    dec.configure(f, null, null, 0); dec.start();
    int ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT), sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE);
    long want = Math.max(0, (endMs - startMs)) * 16, total = 0, skip = 0, inBase = 0; boolean first = true, inDone = false, outDone = false;
    double step = sr / 16000.0, x = 0, last = 0;
    MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
    try (BufferedOutputStream os = new BufferedOutputStream(new FileOutputStream(out), 1 << 16)) {
      while (!outDone && (want == 0 || total < want)) {
        if (!inDone) { int ii = dec.dequeueInputBuffer(10000);
          if (ii >= 0) { ByteBuffer ib = dec.getInputBuffer(ii); int n = ex.readSampleData(ib, 0);
            if (n < 0) { dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true; }
            else { dec.queueInputBuffer(ii, 0, n, ex.getSampleTime(), 0); ex.advance(); } } }
        int oi = dec.dequeueOutputBuffer(bi, 10000);
        if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { MediaFormat nf = dec.getOutputFormat();
          ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT); sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE); step = sr / 16000.0; }
        else if (oi >= 0) {
          ShortBuffer sb = dec.getOutputBuffer(oi).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer();
          int frames = bi.size / 2 / ch;
          if (first && frames > 0) { skip = (long) Math.max(0, (startMs * 1000 - bi.presentationTimeUs) * (double) sr / 1e6); first = false; }
          int from = (int) Math.min(skip, frames); skip -= from; int len = frames - from;
          if (len > 0) {
            double[] m = new double[len];
            for (int i = 0; i < len; i++) { double s = 0; for (int c = 0; c < ch; c++) s += sb.get((from + i) * ch + c); m[i] = s / ch; }
            byte[] ob = new byte[(int) (len / step + 2) * 2]; int ox = 0;
            while ((long) Math.floor(x) + 1 < inBase + len) {
              long i0 = (long) Math.floor(x); double s0 = i0 < inBase ? last : m[(int) (i0 - inBase)], s1 = m[(int) (i0 + 1 - inBase)];
              short y = (short) Math.round(s0 + (s1 - s0) * (x - i0)); ob[ox++] = (byte) y; ob[ox++] = (byte) (y >> 8); x += step; total++;
            }
            inBase += len; last = m[len - 1]; os.write(ob, 0, ox);
          }
          dec.releaseOutputBuffer(oi, false);
          if ((bi.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
        }
      }
    } finally { dec.stop(); dec.release(); ex.release(); }
    return want > 0 ? Math.min(total, want) : total;
  }
}
