package com.srt.transcriber;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.*;

public class MainActivity extends Activity {
  WebView web; NativeBridge nb;
  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    web = new WebView(this); web.setBackgroundColor(0xFF0F172A); setContentView(web);
    WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
    nb = new NativeBridge(this, web); web.addJavascriptInterface(nb, "Android");
    web.setWebChromeClient(new WebChromeClient());
    web.loadUrl("file:///android_asset/www/index.html");
  }
  @Override protected void onActivityResult(int req, int res, Intent d) { nb.onResult(req, res, d); }
}
