package com.srt.transcriber;
public class WhisperBridge {
  static { System.loadLibrary("whisperjni"); }
  public interface Listener { void onSegment(long t0cs, long t1cs, byte[] utf8); void onProgress(int p); }
  public static native long init(String modelPath);
  public static native int run(long ctx, float[] pcm, String lang, boolean translate, int threads, Listener l);
  public static native void free(long ctx);
  public static native void abort(boolean v);
}
