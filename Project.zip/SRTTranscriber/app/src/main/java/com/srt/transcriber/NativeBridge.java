package com.srt.transcriber;

import android.app.Activity;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.PowerManager;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

public class NativeBridge {
  private final MainActivity act; private final WebView web;
  private final ExecutorService pool = Executors.newCachedThreadPool();
  private long ctx = 0; private String ctxName = "";
  private String pId, pKind, pText; private JSONObject pArgs;

  NativeBridge(MainActivity a, WebView w) { act = a; web = w; }
  private File dir() { File d = new File(act.getFilesDir(), "models"); d.mkdirs(); return d; }
  private void js(String s) { web.post(() -> web.evaluateJavascript(s, null)); }
  private void ok(String id, JSONObject o) { js("window.__res(" + JSONObject.quote(id) + ",true," + o + ")"); }
  private void err(String id, String m) { try { JSONObject o = new JSONObject(); o.put("error", String.valueOf(m)); js("window.__res(" + JSONObject.quote(id) + ",false," + o + ")"); } catch (Exception e) {} }
  private void emit(String n, JSONObject o) { js("window.__ev(" + JSONObject.quote(n) + "," + o + ")"); }
  private void emit(String n, String k, Object v) { try { emit(n, new JSONObject().put(k, v)); } catch (Exception e) {} }

  @JavascriptInterface public void copy(String t) {
    ((ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("srt", t));
  }

  @JavascriptInterface public void call(String id, String m, String json) {
    pool.execute(() -> {
      try {
        JSONObject a = new JSONObject(json);
        switch (m) {
          case "hasModel": { File f = new File(dir(), a.getString("name")); ok(id, new JSONObject().put("exists", f.exists() && f.length() > 1_000_000)); break; }
          case "pickAudio": pick(id, "audio", a, new String[]{"audio/*", "video/mp4"}, false); break;
          case "pickModel": pick(id, "model", a, null, false); break;
          case "saveFile": pText = a.getString("text"); pick(id, "save", a, null, true); break;
          case "downloadModel": download(id, a); break;
          case "transcribe": transcribe(id, a); break;
          case "cancel": WhisperBridge.abort(true); ok(id, new JSONObject()); break;
          default: err(id, "unknown " + m);
        }
      } catch (Throwable e) { err(id, e.getMessage()); }
    });
  }

  private void pick(String id, String kind, JSONObject a, String[] mimes, boolean create) {
    act.runOnUiThread(() -> {
      pId = id; pKind = kind; pArgs = a;
      Intent i = new Intent(create ? Intent.ACTION_CREATE_DOCUMENT : Intent.ACTION_OPEN_DOCUMENT);
      i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
      if (mimes != null) i.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
      if (create) i.putExtra(Intent.EXTRA_TITLE, a.optString("name", "subtitle.srt"));
      act.startActivityForResult(i, 1);
    });
  }

  void onResult(int req, int res, Intent d) {
    final String id = pId, kind = pKind; final JSONObject a = pArgs;
    if (id == null) return;
    if (res != Activity.RESULT_OK || d == null || d.getData() == null) { err(id, "cancelled"); return; }
    final Uri u = d.getData();
    pool.execute(() -> {
      try {
        ContentResolver cr = act.getContentResolver();
        String name = "file"; long size = 0;
        try (Cursor q = cr.query(u, null, null, null, null)) {
          if (q != null && q.moveToFirst()) { name = q.getString(q.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)); size = q.getLong(q.getColumnIndexOrThrow(OpenableColumns.SIZE)); } }
        if (kind.equals("audio")) {
          ok(id, new JSONObject().put("uri", u.toString()).put("name", name).put("durationMs", AudioDecoder.durationMs(act, u)));
        } else if (kind.equals("save")) {
          try (OutputStream o = cr.openOutputStream(u)) { o.write(pText.getBytes(StandardCharsets.UTF_8)); }
          ok(id, new JSONObject());
        } else { // model: คัดลอกเข้าพื้นที่แอป
          File fin = new File(dir(), a.getString("name")), part = new File(fin.getPath() + ".part");
          try (InputStream in = cr.openInputStream(u); OutputStream o = new FileOutputStream(part)) {
            byte[] b = new byte[1 << 20]; int n; long t = 0, lp = -1;
            while ((n = in.read(b)) > 0) { o.write(b, 0, n); t += n; long p = size > 0 ? t * 100 / size : 0; if (p != lp) { lp = p; emit("dlprogress", "p", p); } }
          }
          try (FileInputStream f = new FileInputStream(part)) { byte[] h = new byte[4]; f.read(h);
            if (!(h[0] == 'l' && h[1] == 'm' && h[2] == 'g' && h[3] == 'g')) { part.delete(); throw new IOException("ไฟล์นี้ไม่ใช่โมเดล ggml (.bin) ของ whisper.cpp"); } }
          fin.delete(); part.renameTo(fin); ok(id, new JSONObject());
        }
      } catch (Throwable e) { err(id, e.getMessage()); }
    });
  }

  private void download(String id, JSONObject a) throws Exception {
    File fin = new File(dir(), a.getString("name")), part = new File(fin.getPath() + ".part");
    HttpURLConnection h = (HttpURLConnection) new URL(a.getString("url")).openConnection();
    long have = part.exists() ? part.length() : 0; if (have > 0) h.setRequestProperty("Range", "bytes=" + have + "-");
    h.setConnectTimeout(20000); h.setReadTimeout(30000); h.connect();
    if (h.getResponseCode() == 416) { part.renameTo(fin); ok(id, new JSONObject()); return; }
    boolean resume = h.getResponseCode() == 206; if (!resume) have = 0;
    long tot = have + h.getContentLengthLong(), got = have, lp = -1;
    try (InputStream in = h.getInputStream(); FileOutputStream out = new FileOutputStream(part, resume)) {
      byte[] b = new byte[1 << 16]; int n;
      while ((n = in.read(b)) > 0) { out.write(b, 0, n); got += n; long p = tot > 0 ? got * 100 / tot : 0; if (p != lp) { lp = p; emit("dlprogress", "p", p); } }
    }
    if (!part.renameTo(fin)) throw new IOException("rename failed");
    ok(id, new JSONObject());
  }

  private void transcribe(String id, JSONObject a) {
    PowerManager.WakeLock wl = ((PowerManager) act.getSystemService(Context.POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "srt:tx");
    wl.acquire(6 * 3600 * 1000L);
    act.runOnUiThread(() -> web.setKeepScreenOn(true));
    File pcm = new File(act.getCacheDir(), "tx.pcm");
    try {
      Uri uri = Uri.parse(a.getString("uri")); String model = a.getString("model"), lang = a.optString("lang", "ja");
      boolean tr = a.optBoolean("translate"), vad = a.optBoolean("vad");
      long st = Math.round(a.optDouble("startMs", 0)), en = Math.round(a.optDouble("endMs", 0));
      long chunk = Math.max(10, Math.round(a.optDouble("chunkSec", 120))) * 16000L;
      emit("step", "n", 0);
      if (ctx == 0 || !model.equals(ctxName)) {
        if (ctx != 0) WhisperBridge.free(ctx);
        ctx = WhisperBridge.init(new File(dir(), model).getPath()); ctxName = model;
        if (ctx == 0) throw new IOException("โหลดโมเดลไม่สำเร็จ (ไฟล์ไม่ถูกต้อง?)");
      }
      emit("step", "n", 1);
      long total = AudioDecoder.decode(act, uri, st, en, pcm);
      emit("step", "n", 2);
      int N = (int) Math.max(1, (total + chunk - 1) / chunk);
      emit("step", "n", 3);
      try (RandomAccessFile raf = new RandomAccessFile(pcm, "r")) {
        for (int i = 0; i < N; i++) {
          long off = i * chunk, len = Math.min(chunk, total - off);
          byte[] raw = new byte[(int) len * 2]; raf.seek(off * 2); raf.readFully(raw);
          final short[] sh = new short[(int) len]; ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(sh);
          double e2 = 0; for (short s : sh) e2 += (double) s * s;
          if (vad && Math.sqrt(e2 / Math.max(1, len)) < 40) { emit("progress", "p", (i + 1.0) / N); continue; }
          float[] f = new float[(int) Math.max(len, 16000)]; for (int k = 0; k < len; k++) f[k] = sh[k] / 32768f;
          final long base = st + off / 16; final int ci = i; final int NN = N;
          int rc = WhisperBridge.run(ctx, f, lang, tr, 4, new WhisperBridge.Listener() {
            public void onSegment(long t0, long t1, byte[] tx) {
              String t = new String(tx, StandardCharsets.UTF_8).trim(); if (t.isEmpty()) return;
              long[] r = Refiner.snap(sh, base, base + t0 * 10, base + t1 * 10);
              try { emit("segment", new JSONObject().put("s", r[0]).put("e", r[1]).put("t", t)); } catch (Exception e) {}
            }
            public void onProgress(int p) { emit("progress", "p", (ci + p / 100.0) / NN); }
          });
          if (rc != 0) { if (rc == -6) break; throw new IOException("whisper error " + rc); }
        }
      }
      emit("step", "n", 4); ok(id, new JSONObject());
    } catch (Throwable e) { err(id, e.getMessage()); }
    finally { wl.release(); pcm.delete(); act.runOnUiThread(() -> web.setKeepScreenOn(false)); }
  }
}
