package com.srt.transcriber;
/** Whisper ให้เวลาละเอียดแค่ 10ms → ปรับขอบ cue ตามพลังงานเสียงจริงในระดับ 5ms (sample-accurate) */
class Refiner {
  static final int F = 80; // 5ms @16kHz
  static double rms(short[] x, int a) { double s = 0; int e = Math.min(x.length, a + F); if (a < 0 || e <= a) return 0;
    for (int i = a; i < e; i++) s += (double) x[i] * x[i]; return Math.sqrt(s / (e - a)); }
  /** base = เวลา(ms) ของ sample แรกใน x; คืน {startMs,endMs} */
  static long[] snap(short[] x, long base, long s, long e) {
    int si = (int) ((s - base) * 16), ei = (int) ((e - base) * 16);
    if (si < 0 || ei > x.length || ei <= si) return new long[]{s, e};
    double pk = 0; for (int i = si; i + F <= ei; i += F) pk = Math.max(pk, rms(x, i));
    double thr = Math.max(120, pk * 0.12); int W = 250 * 16;
    int ns = si, ne = ei;
    for (int i = Math.max(0, si - W); i < Math.min(x.length - 3 * F, si + W); i += F)
      if (rms(x, i) > thr && rms(x, i + F) > thr && rms(x, i + 2 * F) > thr) { ns = i; break; }
    for (int i = Math.min(x.length - F, ei + W); i > Math.max(0, ei - W); i -= F)
      if (rms(x, i) > thr && rms(x, i - F) > thr) { ne = Math.min(x.length, i + F + 16 * 20); break; }
    if (ne <= ns) return new long[]{s, e};
    return new long[]{base + ns / 16, base + ne / 16};
  }
}
