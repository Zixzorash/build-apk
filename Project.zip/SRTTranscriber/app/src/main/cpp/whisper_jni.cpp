#include <jni.h>
#include <atomic>
#include <string>
#include "whisper.h"

static std::atomic<bool> g_abort{false};
struct Cb { JNIEnv* env; jobject l; jmethodID seg; jmethodID prog; };

static void on_seg(whisper_context* c, whisper_state*, int n_new, void* ud) {
  auto* x = (Cb*)ud; int n = whisper_full_n_segments(c);
  for (int i = n - n_new; i < n; i++) {
    const char* t = whisper_full_get_segment_text(c, i);
    jsize len = (jsize)strlen(t);
    jbyteArray a = x->env->NewByteArray(len);
    x->env->SetByteArrayRegion(a, 0, len, (const jbyte*)t);
    x->env->CallVoidMethod(x->l, x->seg, (jlong)whisper_full_get_segment_t0(c, i),
                           (jlong)whisper_full_get_segment_t1(c, i), a);
    x->env->DeleteLocalRef(a);
  }
}
static void on_prog(whisper_context*, whisper_state*, int p, void* ud) {
  auto* x = (Cb*)ud; x->env->CallVoidMethod(x->l, x->prog, (jint)p);
}

extern "C" {
JNIEXPORT jlong JNICALL Java_com_srt_transcriber_WhisperBridge_init(JNIEnv* env, jclass, jstring path) {
  const char* p = env->GetStringUTFChars(path, nullptr);
  auto cp = whisper_context_default_params(); cp.use_gpu = false;
  whisper_context* c = whisper_init_from_file_with_params(p, cp);
  env->ReleaseStringUTFChars(path, p); return (jlong)c;
}
JNIEXPORT jint JNICALL Java_com_srt_transcriber_WhisperBridge_run(JNIEnv* env, jclass, jlong ctx, jfloatArray pcm,
    jstring lang, jboolean tr, jint threads, jobject l) {
  auto* c = (whisper_context*)ctx; g_abort = false;
  jclass k = env->GetObjectClass(l);
  Cb cb{env, l, env->GetMethodID(k, "onSegment", "(JJ[B)V"), env->GetMethodID(k, "onProgress", "(I)V")};
  const char* lc = env->GetStringUTFChars(lang, nullptr); std::string ls(lc);
  env->ReleaseStringUTFChars(lang, lc);
  auto p = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
  p.n_threads = threads; p.language = ls.c_str(); p.detect_language = (ls == "auto"); p.translate = tr;
  p.print_progress = p.print_realtime = p.print_special = p.print_timestamps = false;
  p.no_context = true; p.token_timestamps = true; p.greedy.best_of = 1;
  p.new_segment_callback = on_seg; p.new_segment_callback_user_data = &cb;
  p.progress_callback = on_prog; p.progress_callback_user_data = &cb;
  p.abort_callback = [](void*) { return g_abort.load(); }; p.abort_callback_user_data = nullptr;
  jfloat* d = env->GetFloatArrayElements(pcm, nullptr);
  int r = whisper_full(c, p, d, env->GetArrayLength(pcm));
  env->ReleaseFloatArrayElements(pcm, d, JNI_ABORT); return r;
}
JNIEXPORT void JNICALL Java_com_srt_transcriber_WhisperBridge_free(JNIEnv*, jclass, jlong ctx) { whisper_free((whisper_context*)ctx); }
JNIEXPORT void JNICALL Java_com_srt_transcriber_WhisperBridge_abort(JNIEnv*, jclass, jboolean v) { g_abort = v; }
}
